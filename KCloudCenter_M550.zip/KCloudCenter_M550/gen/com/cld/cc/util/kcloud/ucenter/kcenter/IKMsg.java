/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Original file: D:\\work\\project\\K��\\KCloudCenter_M550\\src\\com\\cld\\cc\\util\\kcloud\\ucenter\\kcenter\\IKMsg.aidl
 */
package com.cld.cc.util.kcloud.ucenter.kcenter;
public interface IKMsg extends android.os.IInterface
{
/** Local-side IPC implementation stub class. */
public static abstract class Stub extends android.os.Binder implements com.cld.cc.util.kcloud.ucenter.kcenter.IKMsg
{
private static final java.lang.String DESCRIPTOR = "com.cld.cc.util.kcloud.ucenter.kcenter.IKMsg";
/** Construct the stub at attach it to the interface. */
public Stub()
{
this.attachInterface(this, DESCRIPTOR);
}
/**
 * Cast an IBinder object into an com.cld.cc.util.kcloud.ucenter.kcenter.IKMsg interface,
 * generating a proxy if needed.
 */
public static com.cld.cc.util.kcloud.ucenter.kcenter.IKMsg asInterface(android.os.IBinder obj)
{
if ((obj==null)) {
return null;
}
android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
if (((iin!=null)&&(iin instanceof com.cld.cc.util.kcloud.ucenter.kcenter.IKMsg))) {
return ((com.cld.cc.util.kcloud.ucenter.kcenter.IKMsg)iin);
}
return new com.cld.cc.util.kcloud.ucenter.kcenter.IKMsg.Stub.Proxy(obj);
}
@Override public android.os.IBinder asBinder()
{
return this;
}
@Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
{
switch (code)
{
case INTERFACE_TRANSACTION:
{
reply.writeString(DESCRIPTOR);
return true;
}
case TRANSACTION_getDeviceMsgHistory:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
java.util.List<com.cld.cc.util.kcloud.ucenter.kcenter.CldSysMessageParce> _result = this.getDeviceMsgHistory(_arg0);
reply.writeNoException();
reply.writeTypedList(_result);
return true;
}
case TRANSACTION_getDeviceMsgHistoryDownOrUp:
{
data.enforceInterface(DESCRIPTOR);
long _arg0;
_arg0 = data.readLong();
long _arg1;
_arg1 = data.readLong();
int _arg2;
_arg2 = data.readInt();
boolean _arg3;
_arg3 = (0!=data.readInt());
java.util.List<com.cld.cc.util.kcloud.ucenter.kcenter.CldSysMessageParce> _result = this.getDeviceMsgHistoryDownOrUp(_arg0, _arg1, _arg2, _arg3);
reply.writeNoException();
reply.writeTypedList(_result);
return true;
}
case TRANSACTION_getUserMsgHitory:
{
data.enforceInterface(DESCRIPTOR);
long _arg0;
_arg0 = data.readLong();
int _arg1;
_arg1 = data.readInt();
java.util.List<com.cld.cc.util.kcloud.ucenter.kcenter.CldSysMessageParce> _result = this.getUserMsgHitory(_arg0, _arg1);
reply.writeNoException();
reply.writeTypedList(_result);
return true;
}
case TRANSACTION_getUserMsgHistoryDownOrUp:
{
data.enforceInterface(DESCRIPTOR);
long _arg0;
_arg0 = data.readLong();
long _arg1;
_arg1 = data.readLong();
long _arg2;
_arg2 = data.readLong();
int _arg3;
_arg3 = data.readInt();
boolean _arg4;
_arg4 = (0!=data.readInt());
java.util.List<com.cld.cc.util.kcloud.ucenter.kcenter.CldSysMessageParce> _result = this.getUserMsgHistoryDownOrUp(_arg0, _arg1, _arg2, _arg3, _arg4);
reply.writeNoException();
reply.writeTypedList(_result);
return true;
}
case TRANSACTION_saveMsgHitory:
{
data.enforceInterface(DESCRIPTOR);
java.util.List<com.cld.cc.util.kcloud.ucenter.kcenter.CldSysMessageParce> _arg0;
_arg0 = data.createTypedArrayList(com.cld.cc.util.kcloud.ucenter.kcenter.CldSysMessageParce.CREATOR);
long _arg1;
_arg1 = data.readLong();
this.saveMsgHitory(_arg0, _arg1);
reply.writeNoException();
return true;
}
case TRANSACTION_updateMsgReadStatus:
{
data.enforceInterface(DESCRIPTOR);
java.util.List<com.cld.cc.util.kcloud.ucenter.kcenter.CldSysMessageParce> _arg0;
_arg0 = data.createTypedArrayList(com.cld.cc.util.kcloud.ucenter.kcenter.CldSysMessageParce.CREATOR);
boolean _arg1;
_arg1 = (0!=data.readInt());
this.updateMsgReadStatus(_arg0, _arg1);
reply.writeNoException();
return true;
}
case TRANSACTION_getReadMsg:
{
data.enforceInterface(DESCRIPTOR);
java.util.List<com.cld.cc.util.kcloud.ucenter.kcenter.CldSysMessageParce> _result = this.getReadMsg();
reply.writeNoException();
reply.writeTypedList(_result);
return true;
}
case TRANSACTION_getUnReadMsgCount:
{
data.enforceInterface(DESCRIPTOR);
long _arg0;
_arg0 = data.readLong();
int _result = this.getUnReadMsgCount(_arg0);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
}
return super.onTransact(code, data, reply, flags);
}
private static class Proxy implements com.cld.cc.util.kcloud.ucenter.kcenter.IKMsg
{
private android.os.IBinder mRemote;
Proxy(android.os.IBinder remote)
{
mRemote = remote;
}
@Override public android.os.IBinder asBinder()
{
return mRemote;
}
public java.lang.String getInterfaceDescriptor()
{
return DESCRIPTOR;
}
@Override public java.util.List<com.cld.cc.util.kcloud.ucenter.kcenter.CldSysMessageParce> getDeviceMsgHistory(int size) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
java.util.List<com.cld.cc.util.kcloud.ucenter.kcenter.CldSysMessageParce> _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(size);
mRemote.transact(Stub.TRANSACTION_getDeviceMsgHistory, _data, _reply, 0);
_reply.readException();
_result = _reply.createTypedArrayList(com.cld.cc.util.kcloud.ucenter.kcenter.CldSysMessageParce.CREATOR);
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
@Override public java.util.List<com.cld.cc.util.kcloud.ucenter.kcenter.CldSysMessageParce> getDeviceMsgHistoryDownOrUp(long lastid, long lasttime, int size, boolean isDownOrUp) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
java.util.List<com.cld.cc.util.kcloud.ucenter.kcenter.CldSysMessageParce> _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeLong(lastid);
_data.writeLong(lasttime);
_data.writeInt(size);
_data.writeInt(((isDownOrUp)?(1):(0)));
mRemote.transact(Stub.TRANSACTION_getDeviceMsgHistoryDownOrUp, _data, _reply, 0);
_reply.readException();
_result = _reply.createTypedArrayList(com.cld.cc.util.kcloud.ucenter.kcenter.CldSysMessageParce.CREATOR);
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
@Override public java.util.List<com.cld.cc.util.kcloud.ucenter.kcenter.CldSysMessageParce> getUserMsgHitory(long kuid, int size) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
java.util.List<com.cld.cc.util.kcloud.ucenter.kcenter.CldSysMessageParce> _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeLong(kuid);
_data.writeInt(size);
mRemote.transact(Stub.TRANSACTION_getUserMsgHitory, _data, _reply, 0);
_reply.readException();
_result = _reply.createTypedArrayList(com.cld.cc.util.kcloud.ucenter.kcenter.CldSysMessageParce.CREATOR);
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
@Override public java.util.List<com.cld.cc.util.kcloud.ucenter.kcenter.CldSysMessageParce> getUserMsgHistoryDownOrUp(long kuid, long lastid, long lasttime, int size, boolean isDownOrUp) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
java.util.List<com.cld.cc.util.kcloud.ucenter.kcenter.CldSysMessageParce> _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeLong(kuid);
_data.writeLong(lastid);
_data.writeLong(lasttime);
_data.writeInt(size);
_data.writeInt(((isDownOrUp)?(1):(0)));
mRemote.transact(Stub.TRANSACTION_getUserMsgHistoryDownOrUp, _data, _reply, 0);
_reply.readException();
_result = _reply.createTypedArrayList(com.cld.cc.util.kcloud.ucenter.kcenter.CldSysMessageParce.CREATOR);
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
@Override public void saveMsgHitory(java.util.List<com.cld.cc.util.kcloud.ucenter.kcenter.CldSysMessageParce> lstMsg, long kuid) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeTypedList(lstMsg);
_data.writeLong(kuid);
mRemote.transact(Stub.TRANSACTION_saveMsgHitory, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
@Override public void updateMsgReadStatus(java.util.List<com.cld.cc.util.kcloud.ucenter.kcenter.CldSysMessageParce> clickLst, boolean isUp) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeTypedList(clickLst);
_data.writeInt(((isUp)?(1):(0)));
mRemote.transact(Stub.TRANSACTION_updateMsgReadStatus, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
@Override public java.util.List<com.cld.cc.util.kcloud.ucenter.kcenter.CldSysMessageParce> getReadMsg() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
java.util.List<com.cld.cc.util.kcloud.ucenter.kcenter.CldSysMessageParce> _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getReadMsg, _data, _reply, 0);
_reply.readException();
_result = _reply.createTypedArrayList(com.cld.cc.util.kcloud.ucenter.kcenter.CldSysMessageParce.CREATOR);
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
@Override public int getUnReadMsgCount(long kuid) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeLong(kuid);
mRemote.transact(Stub.TRANSACTION_getUnReadMsgCount, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
}
static final int TRANSACTION_getDeviceMsgHistory = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
static final int TRANSACTION_getDeviceMsgHistoryDownOrUp = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
static final int TRANSACTION_getUserMsgHitory = (android.os.IBinder.FIRST_CALL_TRANSACTION + 2);
static final int TRANSACTION_getUserMsgHistoryDownOrUp = (android.os.IBinder.FIRST_CALL_TRANSACTION + 3);
static final int TRANSACTION_saveMsgHitory = (android.os.IBinder.FIRST_CALL_TRANSACTION + 4);
static final int TRANSACTION_updateMsgReadStatus = (android.os.IBinder.FIRST_CALL_TRANSACTION + 5);
static final int TRANSACTION_getReadMsg = (android.os.IBinder.FIRST_CALL_TRANSACTION + 6);
static final int TRANSACTION_getUnReadMsgCount = (android.os.IBinder.FIRST_CALL_TRANSACTION + 7);
}
public java.util.List<com.cld.cc.util.kcloud.ucenter.kcenter.CldSysMessageParce> getDeviceMsgHistory(int size) throws android.os.RemoteException;
public java.util.List<com.cld.cc.util.kcloud.ucenter.kcenter.CldSysMessageParce> getDeviceMsgHistoryDownOrUp(long lastid, long lasttime, int size, boolean isDownOrUp) throws android.os.RemoteException;
public java.util.List<com.cld.cc.util.kcloud.ucenter.kcenter.CldSysMessageParce> getUserMsgHitory(long kuid, int size) throws android.os.RemoteException;
public java.util.List<com.cld.cc.util.kcloud.ucenter.kcenter.CldSysMessageParce> getUserMsgHistoryDownOrUp(long kuid, long lastid, long lasttime, int size, boolean isDownOrUp) throws android.os.RemoteException;
public void saveMsgHitory(java.util.List<com.cld.cc.util.kcloud.ucenter.kcenter.CldSysMessageParce> lstMsg, long kuid) throws android.os.RemoteException;
public void updateMsgReadStatus(java.util.List<com.cld.cc.util.kcloud.ucenter.kcenter.CldSysMessageParce> clickLst, boolean isUp) throws android.os.RemoteException;
public java.util.List<com.cld.cc.util.kcloud.ucenter.kcenter.CldSysMessageParce> getReadMsg() throws android.os.RemoteException;
public int getUnReadMsgCount(long kuid) throws android.os.RemoteException;
}
