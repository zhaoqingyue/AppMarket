/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Original file: D:\\work\\project\\K��\\KCloudCenter_M550\\src\\cld\\kcloud\\service\\aidl\\IKCloudClient.aidl
 */
package cld.kcloud.service.aidl;
public interface IKCloudClient extends android.os.IInterface
{
/** Local-side IPC implementation stub class. */
public static abstract class Stub extends android.os.Binder implements cld.kcloud.service.aidl.IKCloudClient
{
private static final java.lang.String DESCRIPTOR = "cld.kcloud.service.aidl.IKCloudClient";
/** Construct the stub at attach it to the interface. */
public Stub()
{
this.attachInterface(this, DESCRIPTOR);
}
/**
 * Cast an IBinder object into an cld.kcloud.service.aidl.IKCloudClient interface,
 * generating a proxy if needed.
 */
public static cld.kcloud.service.aidl.IKCloudClient asInterface(android.os.IBinder obj)
{
if ((obj==null)) {
return null;
}
android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
if (((iin!=null)&&(iin instanceof cld.kcloud.service.aidl.IKCloudClient))) {
return ((cld.kcloud.service.aidl.IKCloudClient)iin);
}
return new cld.kcloud.service.aidl.IKCloudClient.Stub.Proxy(obj);
}
@Override public android.os.IBinder asBinder()
{
return this;
}
@Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
{
switch (code)
{
case INTERFACE_TRANSACTION:
{
reply.writeString(DESCRIPTOR);
return true;
}
case TRANSACTION_onLoginListener:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
this.onLoginListener(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_onLogoutListener:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
this.onLogoutListener(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_onUpdateInfoListener:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
this.onUpdateInfoListener(_arg0);
reply.writeNoException();
return true;
}
}
return super.onTransact(code, data, reply, flags);
}
private static class Proxy implements cld.kcloud.service.aidl.IKCloudClient
{
private android.os.IBinder mRemote;
Proxy(android.os.IBinder remote)
{
mRemote = remote;
}
@Override public android.os.IBinder asBinder()
{
return mRemote;
}
public java.lang.String getInterfaceDescriptor()
{
return DESCRIPTOR;
}
@Override public void onLoginListener(java.lang.String result) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(result);
mRemote.transact(Stub.TRANSACTION_onLoginListener, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
@Override public void onLogoutListener(java.lang.String result) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(result);
mRemote.transact(Stub.TRANSACTION_onLogoutListener, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
@Override public void onUpdateInfoListener(java.lang.String result) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(result);
mRemote.transact(Stub.TRANSACTION_onUpdateInfoListener, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
}
static final int TRANSACTION_onLoginListener = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
static final int TRANSACTION_onLogoutListener = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
static final int TRANSACTION_onUpdateInfoListener = (android.os.IBinder.FIRST_CALL_TRANSACTION + 2);
}
public void onLoginListener(java.lang.String result) throws android.os.RemoteException;
public void onLogoutListener(java.lang.String result) throws android.os.RemoteException;
public void onUpdateInfoListener(java.lang.String result) throws android.os.RemoteException;
}
