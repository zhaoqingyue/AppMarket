/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Original file: D:\\work\\project\\K��\\KCloudCenter_M550\\src\\cld\\kcloud\\service\\aidl\\IKCloudService.aidl
 */
package cld.kcloud.service.aidl;
public interface IKCloudService extends android.os.IInterface
{
/** Local-side IPC implementation stub class. */
public static abstract class Stub extends android.os.Binder implements cld.kcloud.service.aidl.IKCloudService
{
private static final java.lang.String DESCRIPTOR = "cld.kcloud.service.aidl.IKCloudService";
/** Construct the stub at attach it to the interface. */
public Stub()
{
this.attachInterface(this, DESCRIPTOR);
}
/**
 * Cast an IBinder object into an cld.kcloud.service.aidl.IKCloudService interface,
 * generating a proxy if needed.
 */
public static cld.kcloud.service.aidl.IKCloudService asInterface(android.os.IBinder obj)
{
if ((obj==null)) {
return null;
}
android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
if (((iin!=null)&&(iin instanceof cld.kcloud.service.aidl.IKCloudService))) {
return ((cld.kcloud.service.aidl.IKCloudService)iin);
}
return new cld.kcloud.service.aidl.IKCloudService.Stub.Proxy(obj);
}
@Override public android.os.IBinder asBinder()
{
return this;
}
@Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
{
switch (code)
{
case INTERFACE_TRANSACTION:
{
reply.writeString(DESCRIPTOR);
return true;
}
case TRANSACTION_start_KLD_app:
{
data.enforceInterface(DESCRIPTOR);
this.start_KLD_app();
reply.writeNoException();
return true;
}
case TRANSACTION_start_KLD_kcenter:
{
data.enforceInterface(DESCRIPTOR);
this.start_KLD_kcenter();
reply.writeNoException();
return true;
}
case TRANSACTION_get_KLD_account:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _result = this.get_KLD_account();
reply.writeNoException();
reply.writeString(_result);
return true;
}
case TRANSACTION_get_KLD_login_result:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _result = this.get_KLD_login_result();
reply.writeNoException();
reply.writeString(_result);
return true;
}
case TRANSACTION_set_DDH_account:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
this.set_DDH_account(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_set_DDH_login_result:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
this.set_DDH_login_result(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_setLoginListener:
{
data.enforceInterface(DESCRIPTOR);
cld.kcloud.service.aidl.IKCloudClient _arg0;
_arg0 = cld.kcloud.service.aidl.IKCloudClient.Stub.asInterface(data.readStrongBinder());
this.setLoginListener(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_notify_KLD_InvalidSession:
{
data.enforceInterface(DESCRIPTOR);
this.notify_KLD_InvalidSession();
reply.writeNoException();
return true;
}
case TRANSACTION_notify_KLD_Message:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
java.lang.String _arg1;
_arg1 = data.readString();
java.lang.String _arg2;
_arg2 = data.readString();
int _arg3;
_arg3 = data.readInt();
this.notify_KLD_Message(_arg0, _arg1, _arg2, _arg3);
reply.writeNoException();
return true;
}
case TRANSACTION_isKOS_RunningApp:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
int _result = this.isKOS_RunningApp(_arg0);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_start_check_simcard:
{
data.enforceInterface(DESCRIPTOR);
this.start_check_simcard();
reply.writeNoException();
return true;
}
case TRANSACTION_jump_to_renew:
{
data.enforceInterface(DESCRIPTOR);
this.jump_to_renew();
reply.writeNoException();
return true;
}
}
return super.onTransact(code, data, reply, flags);
}
private static class Proxy implements cld.kcloud.service.aidl.IKCloudService
{
private android.os.IBinder mRemote;
Proxy(android.os.IBinder remote)
{
mRemote = remote;
}
@Override public android.os.IBinder asBinder()
{
return mRemote;
}
public java.lang.String getInterfaceDescriptor()
{
return DESCRIPTOR;
}
@Override public void start_KLD_app() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_start_KLD_app, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
@Override public void start_KLD_kcenter() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_start_KLD_kcenter, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
@Override public java.lang.String get_KLD_account() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
java.lang.String _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_get_KLD_account, _data, _reply, 0);
_reply.readException();
_result = _reply.readString();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
@Override public java.lang.String get_KLD_login_result() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
java.lang.String _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_get_KLD_login_result, _data, _reply, 0);
_reply.readException();
_result = _reply.readString();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
@Override public void set_DDH_account(java.lang.String accountJson) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(accountJson);
mRemote.transact(Stub.TRANSACTION_set_DDH_account, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
@Override public void set_DDH_login_result(java.lang.String resultJson) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(resultJson);
mRemote.transact(Stub.TRANSACTION_set_DDH_login_result, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
@Override public void setLoginListener(cld.kcloud.service.aidl.IKCloudClient client) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeStrongBinder((((client!=null))?(client.asBinder()):(null)));
mRemote.transact(Stub.TRANSACTION_setLoginListener, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
@Override public void notify_KLD_InvalidSession() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_notify_KLD_InvalidSession, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
@Override public void notify_KLD_Message(java.lang.String app_name, java.lang.String message, java.lang.String btnText, int type) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(app_name);
_data.writeString(message);
_data.writeString(btnText);
_data.writeInt(type);
mRemote.transact(Stub.TRANSACTION_notify_KLD_Message, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
@Override public int isKOS_RunningApp(java.lang.String app_name) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(app_name);
mRemote.transact(Stub.TRANSACTION_isKOS_RunningApp, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
@Override public void start_check_simcard() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_start_check_simcard, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
@Override public void jump_to_renew() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_jump_to_renew, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
}
static final int TRANSACTION_start_KLD_app = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
static final int TRANSACTION_start_KLD_kcenter = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
static final int TRANSACTION_get_KLD_account = (android.os.IBinder.FIRST_CALL_TRANSACTION + 2);
static final int TRANSACTION_get_KLD_login_result = (android.os.IBinder.FIRST_CALL_TRANSACTION + 3);
static final int TRANSACTION_set_DDH_account = (android.os.IBinder.FIRST_CALL_TRANSACTION + 4);
static final int TRANSACTION_set_DDH_login_result = (android.os.IBinder.FIRST_CALL_TRANSACTION + 5);
static final int TRANSACTION_setLoginListener = (android.os.IBinder.FIRST_CALL_TRANSACTION + 6);
static final int TRANSACTION_notify_KLD_InvalidSession = (android.os.IBinder.FIRST_CALL_TRANSACTION + 7);
static final int TRANSACTION_notify_KLD_Message = (android.os.IBinder.FIRST_CALL_TRANSACTION + 8);
static final int TRANSACTION_isKOS_RunningApp = (android.os.IBinder.FIRST_CALL_TRANSACTION + 9);
static final int TRANSACTION_start_check_simcard = (android.os.IBinder.FIRST_CALL_TRANSACTION + 10);
static final int TRANSACTION_jump_to_renew = (android.os.IBinder.FIRST_CALL_TRANSACTION + 11);
}
public void start_KLD_app() throws android.os.RemoteException;
public void start_KLD_kcenter() throws android.os.RemoteException;
public java.lang.String get_KLD_account() throws android.os.RemoteException;
public java.lang.String get_KLD_login_result() throws android.os.RemoteException;
public void set_DDH_account(java.lang.String accountJson) throws android.os.RemoteException;
public void set_DDH_login_result(java.lang.String resultJson) throws android.os.RemoteException;
public void setLoginListener(cld.kcloud.service.aidl.IKCloudClient client) throws android.os.RemoteException;
public void notify_KLD_InvalidSession() throws android.os.RemoteException;
public void notify_KLD_Message(java.lang.String app_name, java.lang.String message, java.lang.String btnText, int type) throws android.os.RemoteException;
public int isKOS_RunningApp(java.lang.String app_name) throws android.os.RemoteException;
public void start_check_simcard() throws android.os.RemoteException;
public void jump_to_renew() throws android.os.RemoteException;
}
