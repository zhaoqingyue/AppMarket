/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Original file: D:\\work\\project\\K��\\KCloudCenter_M550\\src\\cld\\navi\\position\\frame\\IGetParamFromNavi.aidl
 */
package cld.navi.position.frame;
public interface IGetParamFromNavi extends android.os.IInterface
{
/** Local-side IPC implementation stub class. */
public static abstract class Stub extends android.os.Binder implements cld.navi.position.frame.IGetParamFromNavi
{
private static final java.lang.String DESCRIPTOR = "cld.navi.position.frame.IGetParamFromNavi";
/** Construct the stub at attach it to the interface. */
public Stub()
{
this.attachInterface(this, DESCRIPTOR);
}
/**
 * Cast an IBinder object into an cld.navi.position.frame.IGetParamFromNavi interface,
 * generating a proxy if needed.
 */
public static cld.navi.position.frame.IGetParamFromNavi asInterface(android.os.IBinder obj)
{
if ((obj==null)) {
return null;
}
android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
if (((iin!=null)&&(iin instanceof cld.navi.position.frame.IGetParamFromNavi))) {
return ((cld.navi.position.frame.IGetParamFromNavi)iin);
}
return new cld.navi.position.frame.IGetParamFromNavi.Stub.Proxy(obj);
}
@Override public android.os.IBinder asBinder()
{
return this;
}
@Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
{
switch (code)
{
case INTERFACE_TRANSACTION:
{
reply.writeString(DESCRIPTOR);
return true;
}
case TRANSACTION_getKuidFromNavi:
{
data.enforceInterface(DESCRIPTOR);
int _result = this.getKuidFromNavi();
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_getRuidXYFromNavi:
{
data.enforceInterface(DESCRIPTOR);
cld.navi.position.frame.GpsDataParam _result = this.getRuidXYFromNavi();
reply.writeNoException();
if ((_result!=null)) {
reply.writeInt(1);
_result.writeToParcel(reply, android.os.Parcelable.PARCELABLE_WRITE_RETURN_VALUE);
}
else {
reply.writeInt(0);
}
return true;
}
case TRANSACTION_getSessionFromNavi:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _result = this.getSessionFromNavi();
reply.writeNoException();
reply.writeString(_result);
return true;
}
case TRANSACTION_getDuidFromNavi:
{
data.enforceInterface(DESCRIPTOR);
int _result = this.getDuidFromNavi();
reply.writeNoException();
reply.writeInt(_result);
return true;
}
}
return super.onTransact(code, data, reply, flags);
}
private static class Proxy implements cld.navi.position.frame.IGetParamFromNavi
{
private android.os.IBinder mRemote;
Proxy(android.os.IBinder remote)
{
mRemote = remote;
}
@Override public android.os.IBinder asBinder()
{
return mRemote;
}
public java.lang.String getInterfaceDescriptor()
{
return DESCRIPTOR;
}
/**
  *��ȡkuid
  */
@Override public int getKuidFromNavi() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getKuidFromNavi, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
  *��ȡruid�������󾭶ȡ�������γ��
  */
@Override public cld.navi.position.frame.GpsDataParam getRuidXYFromNavi() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
cld.navi.position.frame.GpsDataParam _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getRuidXYFromNavi, _data, _reply, 0);
_reply.readException();
if ((0!=_reply.readInt())) {
_result = cld.navi.position.frame.GpsDataParam.CREATOR.createFromParcel(_reply);
}
else {
_result = null;
}
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
  *��ȡsession
  */
@Override public java.lang.String getSessionFromNavi() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
java.lang.String _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getSessionFromNavi, _data, _reply, 0);
_reply.readException();
_result = _reply.readString();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
  *��ȡduid
  */
@Override public int getDuidFromNavi() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getDuidFromNavi, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
}
static final int TRANSACTION_getKuidFromNavi = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
static final int TRANSACTION_getRuidXYFromNavi = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
static final int TRANSACTION_getSessionFromNavi = (android.os.IBinder.FIRST_CALL_TRANSACTION + 2);
static final int TRANSACTION_getDuidFromNavi = (android.os.IBinder.FIRST_CALL_TRANSACTION + 3);
}
/**
  *��ȡkuid
  */
public int getKuidFromNavi() throws android.os.RemoteException;
/**
  *��ȡruid�������󾭶ȡ�������γ��
  */
public cld.navi.position.frame.GpsDataParam getRuidXYFromNavi() throws android.os.RemoteException;
/**
  *��ȡsession
  */
public java.lang.String getSessionFromNavi() throws android.os.RemoteException;
/**
  *��ȡduid
  */
public int getDuidFromNavi() throws android.os.RemoteException;
}
