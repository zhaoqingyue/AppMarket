package cld.kcloud.utils;

public class KCloudConstantUtil 
{
	public static final int UNIT_GB2MB = 1000;
	
	public static final int FRAGMENT_PERSON = 0;
	public static final int FRAGMENT_CARINFO = 1;
	public static final int FRAGMENT_SERVICE = 2;
	public static final int FRAGMENT_FLOW = 3;
	public static final int FRAGMENT_RENEWAL = 4;
}
