package cld.kmarket.download;

import cld.kcloud.custom.bean.KCloudInstalledInfo;

public class DownloadTest 
{
	public static KCloudInstalledInfo getDefaultAppInfo()
	{
		KCloudInstalledInfo appInfo0 = new KCloudInstalledInfo();
		appInfo0.setAppName("ͬ��˳");
		appInfo0.setPkgName("com.hexin.plat.android");
		appInfo0.setAppUrl("http://download.careland.com.cn/app/yunying/launcher/m550/tonghuashun.apk");
		appInfo0.setPackSize(27115757);
		
		return appInfo0;
	}
}
